/* ===========================================================
   REDOX AGENCY — interaction script
   =========================================================== */
document.addEventListener('DOMContentLoaded', () => {

  /* ---------- header shadow on scroll ---------- */
  const navShell = document.querySelector('.nav-shell');
  const onScrollHeader = () => {
    if (!navShell) return;
    navShell.classList.toggle('scrolled', window.scrollY > 12);
  };
  window.addEventListener('scroll', onScrollHeader, { passive: true });
  onScrollHeader();

  /* ---------- generic reveal-on-scroll ---------- */
  const revealEls = document.querySelectorAll('.reveal, .reveal-scale');
  if (revealEls.length) {
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting) {
          e.target.classList.add('in');
          io.unobserve(e.target);
        }
      });
    }, { threshold: 0.18, rootMargin: '0px 0px -60px 0px' });
    revealEls.forEach((el, i) => {
      el.style.transitionDelay = `${(i % 6) * 60}ms`;
      io.observe(el);
    });
  }

  /* ---------- giant scrub text (REDOX / second banner) ---------- */
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

  function initGiantScrub(wrapSel, opts = {}) {
    const wrap = document.querySelector(wrapSel);
    if (!wrap) return;
    const stage = wrap.querySelector('.giant-stage');
    const text = wrap.querySelector('.giant-text');
    const fromColor = opts.fromColor || getComputedStyle(document.documentElement).getPropertyValue('--peach').trim();
    const toColor = opts.toColor || '#ffffff';

    const hexToRgb = (hex) => {
      hex = hex.replace('#', '');
      if (hex.length === 3) hex = hex.split('').map((c) => c + c).join('');
      const num = parseInt(hex, 16);
      return [num >> 16 & 255, num >> 8 & 255, num & 255];
    };
    const mix = (a, b, t) => a.map((v, i) => Math.round(v + (b[i] - v) * t));
    const rgbFrom = hexToRgb(fromColor.startsWith('#') ? fromColor : '#f8e3d5');
    const rgbTo = hexToRgb(toColor);

    const update = () => {
      const rect = wrap.getBoundingClientRect();
      const total = wrap.offsetHeight - window.innerHeight;
      const progress = clamp(-rect.top / total, 0, 1);
      const scale = 1 + progress * 2.6;
      const translate = progress * -18;
      text.style.transform = `scale(${scale}) translateY(${translate}%)`;
      const mixed = mix(rgbFrom, rgbTo, clamp(progress * 1.3, 0, 1));
      stage.style.background = `rgb(${mixed[0]},${mixed[1]},${mixed[2]})`;
      text.style.opacity = 1 - clamp((progress - 0.75) / 0.25, 0, 1);
    };
    window.addEventListener('scroll', update, { passive: true });
    window.addEventListener('resize', update);
    update();
  }
  initGiantScrub('.giant-wrap', { toColor: '#ffffff' });
  initGiantScrub('.giant-wrap-2', { fromColor: '#faf7f2', toColor: '#f8e3d5' });

  /* ---------- hero video: graceful fallback if playback fails ---------- */
  const heroVideo = document.getElementById('heroVideo');
  const videoBand = document.getElementById('videoBand');
  if (heroVideo && videoBand) {
    const posterUrl = heroVideo.getAttribute('poster');
    let settled = false;
    const activateFallback = () => {
      if (settled) return;
      settled = true;
      videoBand.style.backgroundImage = `url("${posterUrl}")`;
      videoBand.classList.add('fallback');
    };
    heroVideo.addEventListener('error', activateFallback, true);
    heroVideo.addEventListener('stalled', () => {
      setTimeout(() => { if (heroVideo.readyState < 2) activateFallback(); }, 3500);
    });
    heroVideo.addEventListener('playing', () => { settled = true; });
    // if nothing has started playing shortly after load, fall back so it never looks frozen
    setTimeout(() => { if (heroVideo.readyState < 2) activateFallback(); }, 4000);
  }

  /* ---------- client logos falling in ---------- */
  const logoField = document.querySelector('.logo-field');
  if (logoField) {
    const pills = logoField.querySelectorAll('.logo-pill');
    const io2 = new IntersectionObserver((entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting) {
          pills.forEach((p, i) => {
            setTimeout(() => p.classList.add('dropped'), i * 90);
          });
          io2.disconnect();
        }
      });
    }, { threshold: 0.3 });
    io2.observe(logoField);
  }

  /* ---------- curtain "LET'S WORK" pinned scale ---------- */
  const curtainH = document.querySelector('.curtain-h');
  if (curtainH) {
    const h2 = curtainH.querySelector('h2');
    const update = () => {
      const rect = curtainH.getBoundingClientRect();
      const total = curtainH.offsetHeight - window.innerHeight;
      const progress = clamp(-rect.top / total, 0, 1);
      const s = 0.6 + Math.sin(progress * Math.PI) * 0.55;
      h2.style.setProperty('--s', s.toFixed(3));
    };
    window.addEventListener('scroll', update, { passive: true });
    window.addEventListener('resize', update);
    update();
  }

  /* ---------- testimonial word-by-word lighting ---------- */
  const testP = document.querySelector('.testimonial p');
  if (testP) {
    const words = testP.textContent.trim().split(/\s+/);
    testP.innerHTML = words.map((w) => `<span>${w}</span>`).join(' ');
    const spans = testP.querySelectorAll('span');
    const update = () => {
      const rect = testP.getBoundingClientRect();
      const start = window.innerHeight * 0.85;
      const end = window.innerHeight * 0.35;
      const progress = clamp((start - rect.top) / (start - end), 0, 1);
      const lit = Math.round(progress * spans.length);
      spans.forEach((s, i) => s.classList.toggle('lit', i < lit));
    };
    window.addEventListener('scroll', update, { passive: true });
    window.addEventListener('resize', update);
    update();
  }

  /* ---------- floating label inputs need placeholder ---------- */
  document.querySelectorAll('.field input, .field textarea').forEach((el) => {
    if (!el.placeholder) el.placeholder = ' ';
  });

  /* ---------- contact form fake-submit ---------- */
  const form = document.querySelector('.contact-form');
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const btn = form.querySelector('.submit-row .pill-btn');
      const original = btn.textContent;
      btn.textContent = 'Message sent ✓';
      setTimeout(() => { btn.textContent = original; form.reset(); }, 2200);
    });
  }
  const subForm = document.querySelector('.subscribe-form');
  if (subForm) {
    subForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const input = subForm.querySelector('input');
      input.value = '';
      input.placeholder = 'Subscribed ✓';
    });
  }
});
